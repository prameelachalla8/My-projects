import unittest
from datetime import date, datetime

from taskmanager.exceptions import ValidationError
from taskmanager.models import Priority, Status, Task


class EnumTests(unittest.TestCase):
    def test_priority_parsing_and_order(self):
        self.assertIs(Priority.from_string(" HIGH "), Priority.HIGH)
        self.assertGreater(Priority.HIGH.value, Priority.LOW.value)
        with self.assertRaises(ValidationError):
            Priority.from_string("urgent")

    def test_status_parsing_accepts_variants(self):
        for text in ("in-progress", "in_progress", "In Progress"):
            self.assertIs(Status.from_string(text), Status.IN_PROGRESS)
        with self.assertRaises(ValidationError):
            Status.from_string("later")


class TaskTests(unittest.TestCase):
    def make(self, **kw):
        defaults = dict(task_id=1, title="Write tests")
        defaults.update(kw)
        task_id = defaults.pop("task_id")
        return Task(task_id, **defaults)

    def test_defaults(self):
        task = self.make()
        self.assertEqual(task.priority, Priority.MEDIUM)
        self.assertEqual(task.status, Status.PENDING)
        self.assertIsNone(task.due_date)
        self.assertIsInstance(task.created_at, datetime)

    def test_invalid_id_rejected(self):
        for bad in (0, -1, "1", True, None):
            with self.assertRaises(ValidationError, msg=repr(bad)):
                Task(bad, "x")

    def test_setters_validate(self):
        task = self.make()
        with self.assertRaises(ValidationError):
            task.title = "   "
        with self.assertRaises(ValidationError):
            task.priority = "nope"
        with self.assertRaises(ValidationError):
            task.due_date = "2026-01-01"  # must be a date object
        task.priority = "high"
        self.assertIs(task.priority, Priority.HIGH)

    def test_id_is_read_only(self):
        task = self.make()
        with self.assertRaises(AttributeError):
            task.id = 5

    def test_overdue_logic(self):
        today = date(2026, 6, 10)
        self.assertTrue(self.make(due_date=date(2026, 6, 9)).is_overdue(today))
        self.assertFalse(self.make(due_date=date(2026, 6, 10)).is_overdue(today))
        self.assertFalse(self.make().is_overdue(today))
        done = self.make(due_date=date(2026, 6, 1), status=Status.DONE)
        self.assertFalse(done.is_overdue(today))

    def test_dict_round_trip(self):
        task = self.make(description="d", priority=Priority.HIGH, due_date=date(2030, 1, 2), status=Status.IN_PROGRESS)
        clone = Task.from_dict(task.to_dict())
        self.assertEqual(clone.to_dict(), task.to_dict())

    def test_from_dict_errors(self):
        for bad in ("text", {}, {"id": 1}, {"id": 1, "title": "x", "due_date": "bad"},
                    {"id": 1, "title": "x", "created_at": "bad"}, {"id": 1, "title": "x", "priority": "zzz"}):
            with self.assertRaises(ValidationError, msg=repr(bad)):
                Task.from_dict(bad)


if __name__ == "__main__":
    unittest.main()
