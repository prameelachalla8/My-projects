import unittest
from datetime import date

from taskmanager.exceptions import ValidationError
from taskmanager.validators import (
    MAX_TITLE_LENGTH,
    clean_description,
    clean_title,
    parse_date,
    parse_due_date,
    parse_task_id,
)


class TitleTests(unittest.TestCase):
    def test_trims_and_collapses_spaces(self):
        self.assertEqual(clean_title("  Buy   milk  "), "Buy milk")

    def test_rejects_empty_and_blank(self):
        for bad in ("", "   "):
            with self.assertRaises(ValidationError):
                clean_title(bad)

    def test_rejects_non_text_and_too_long(self):
        with self.assertRaises(ValidationError):
            clean_title(123)
        with self.assertRaises(ValidationError):
            clean_title("x" * (MAX_TITLE_LENGTH + 1))


class DescriptionTests(unittest.TestCase):
    def test_none_becomes_empty(self):
        self.assertEqual(clean_description(None), "")

    def test_too_long_rejected(self):
        with self.assertRaises(ValidationError):
            clean_description("x" * 501)


class DateTests(unittest.TestCase):
    def test_valid_date(self):
        self.assertEqual(parse_date("2026-12-31"), date(2026, 12, 31))

    def test_invalid_formats(self):
        for bad in ("31-12-2026", "2026/12/31", "2026-1-5", "tomorrow", "", None):
            with self.assertRaises(ValidationError, msg=repr(bad)):
                parse_date(bad)

    def test_impossible_date(self):
        with self.assertRaises(ValidationError):
            parse_date("2026-02-30")

    def test_past_due_date_rejected_unless_allowed(self):
        today = date(2026, 6, 1)
        with self.assertRaises(ValidationError):
            parse_due_date("2026-05-31", today=today)
        self.assertEqual(parse_due_date("2026-05-31", allow_past=True, today=today), date(2026, 5, 31))
        self.assertEqual(parse_due_date("2026-06-01", today=today), today)


class TaskIdTests(unittest.TestCase):
    def test_valid(self):
        self.assertEqual(parse_task_id(" 7 "), 7)

    def test_invalid(self):
        for bad in ("abc", "0", "-3", "1.5", ""):
            with self.assertRaises(ValidationError, msg=bad):
                parse_task_id(bad)


if __name__ == "__main__":
    unittest.main()
