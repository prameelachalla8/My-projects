import tempfile
import unittest
from datetime import date
from pathlib import Path

from taskmanager.exceptions import TaskNotFoundError, ValidationError
from taskmanager.models import Priority, Status
from taskmanager.service import TaskManager
from taskmanager.storage import JsonTaskRepository


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = Path(self._tmp.name) / "tasks.json"
        self.manager = self._new_manager()

    def _new_manager(self):
        return TaskManager(JsonTaskRepository(self.path))

    def test_add_assigns_incrementing_ids_and_persists(self):
        a = self.manager.add_task("A")
        b = self.manager.add_task("B")
        self.assertEqual((a.id, b.id), (1, 2))
        self.assertEqual([t.title for t in self._new_manager().list_tasks()], ["A", "B"])

    def test_new_ids_never_collide_after_a_delete(self):
        self.manager.add_task("A")
        self.manager.add_task("B")
        self.manager.delete_task(1)
        self.assertEqual(self.manager.add_task("C").id, 3)

    def test_get_and_not_found(self):
        task = self.manager.add_task("A")
        self.assertIs(self.manager.get_task(task.id), task)
        with self.assertRaises(TaskNotFoundError):
            self.manager.get_task(99)

    def test_filters(self):
        self.manager.add_task("low", priority=Priority.LOW)
        t = self.manager.add_task("high", priority=Priority.HIGH, due_date=date(2020, 1, 1))
        self.manager.mark_done(self.manager.add_task("done").id)
        self.assertEqual([x.title for x in self.manager.list_tasks(priority=Priority.HIGH)], ["high"])
        self.assertEqual([x.title for x in self.manager.list_tasks(status=Status.DONE)], ["done"])
        overdue = self.manager.list_tasks(overdue_only=True, today=date(2026, 1, 1))
        self.assertEqual([x.id for x in overdue], [t.id])

    def test_sorting(self):
        self.manager.add_task("c", priority=Priority.LOW, due_date=date(2030, 1, 3))
        self.manager.add_task("a", priority=Priority.HIGH)
        self.manager.add_task("b", priority=Priority.MEDIUM, due_date=date(2030, 1, 1))
        self.assertEqual([t.title for t in self.manager.list_tasks(sort_by="priority")], ["a", "b", "c"])
        self.assertEqual([t.title for t in self.manager.list_tasks(sort_by="due")], ["b", "c", "a"])
        with self.assertRaises(ValidationError):
            self.manager.list_tasks(sort_by="color")

    def test_update_changes_fields_and_persists(self):
        task = self.manager.add_task("A", due_date=date(2030, 1, 1))
        self.manager.update_task(task.id, title="New", priority=Priority.HIGH, due_date=None)
        reloaded = self._new_manager().get_task(task.id)
        self.assertEqual((reloaded.title, reloaded.priority, reloaded.due_date), ("New", Priority.HIGH, None))

    def test_update_is_atomic_on_invalid_value(self):
        task = self.manager.add_task("Keep me")
        with self.assertRaises(ValidationError):
            self.manager.update_task(task.id, title="Changed", priority="bogus")
        self.assertEqual(self.manager.get_task(task.id).title, "Keep me")

    def test_update_rejects_unknown_and_empty(self):
        task = self.manager.add_task("A")
        with self.assertRaises(ValidationError):
            self.manager.update_task(task.id, colour="red")
        with self.assertRaises(ValidationError):
            self.manager.update_task(task.id)
        with self.assertRaises(TaskNotFoundError):
            self.manager.update_task(42, title="x")

    def test_mark_done_and_delete(self):
        task = self.manager.add_task("A")
        self.assertIs(self.manager.mark_done(task.id).status, Status.DONE)
        removed = self.manager.delete_task(task.id)
        self.assertEqual(removed.title, "A")
        with self.assertRaises(TaskNotFoundError):
            self.manager.delete_task(task.id)


if __name__ == "__main__":
    unittest.main()
