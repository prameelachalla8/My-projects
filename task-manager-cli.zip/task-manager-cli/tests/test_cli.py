import io
import tempfile
import unittest
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from unittest import mock

from taskmanager.cli import main, render_table
from taskmanager.models import Task


class CliTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.file = str(Path(self._tmp.name) / "tasks.json")

    def run_cli(self, *argv):
        out, err = io.StringIO(), io.StringIO()
        with redirect_stdout(out), redirect_stderr(err):
            code = main(["--file", self.file, *argv])
        return code, out.getvalue(), err.getvalue()

    def test_add_list_show(self):
        code, out, _ = self.run_cli("add", "Write report", "-p", "high", "--due", "2099-12-31")
        self.assertEqual(code, 0)
        self.assertIn("Added task #1", out)
        _, out, _ = self.run_cli("list")
        self.assertIn("Write report", out)
        self.assertIn("2099-12-31", out)
        _, out, _ = self.run_cli("show", "1")
        self.assertIn("Priority:    high", out)

    def test_invalid_input_returns_error_code_and_message(self):
        for argv in (["add", "x", "--due", "31/12/2099"], ["add", "x", "-p", "urgent"],
                     ["add", "   "], ["add", "x", "--due", "2000-01-01"]):
            code, _, err = self.run_cli(*argv)
            self.assertEqual(code, 1, argv)
            self.assertTrue(err.startswith("Error:"), argv)

    def test_missing_task_is_a_clean_error(self):
        for cmd in ("show", "done"):
            code, _, err = self.run_cli(cmd, "5")
            self.assertEqual(code, 1)
            self.assertIn("No task found with ID 5", err)
        code, _, err = self.run_cli("show", "abc")
        self.assertEqual(code, 1)
        self.assertIn("Invalid task ID", err)

    def test_update_done_delete(self):
        self.run_cli("add", "Task", "--due", "2099-01-01")
        code, _, _ = self.run_cli("update", "1", "--title", "Renamed", "--status", "in-progress", "--clear-due")
        self.assertEqual(code, 0)
        _, out, _ = self.run_cli("show", "1")
        self.assertIn("Renamed", out)
        self.assertIn("in-progress", out)
        code, _, err = self.run_cli("update", "1", "--due", "2099-01-01", "--clear-due")
        self.assertEqual(code, 1)
        code, _, err = self.run_cli("update", "1")
        self.assertEqual(code, 1)
        self.assertIn("Nothing to update", err)
        self.run_cli("done", "1")
        code, out, _ = self.run_cli("delete", "1", "--yes")
        self.assertEqual(code, 0)
        _, out, _ = self.run_cli("list")
        self.assertIn("No tasks found", out)

    def test_delete_asks_for_confirmation(self):
        self.run_cli("add", "Keep")
        with mock.patch("builtins.input", return_value="n"):
            _, out, _ = self.run_cli("delete", "1")
        self.assertIn("Cancelled", out)
        _, out, _ = self.run_cli("list")
        self.assertIn("Keep", out)
        with mock.patch("builtins.input", return_value="y"):
            self.run_cli("delete", "1")
        _, out, _ = self.run_cli("list")
        self.assertIn("No tasks found", out)

    def test_corrupt_file_reports_storage_error(self):
        Path(self.file).write_text("not json")
        code, _, err = self.run_cli("list")
        self.assertEqual(code, 1)
        self.assertIn("not valid JSON", err)

    def test_menu_flow_recovers_from_bad_input(self):
        inputs = ["1", "", "Menu task", "", "high", "2099-1-1", "2099-01-01",  # add (bad title/date retried)
                  "9",                                                          # invalid menu choice
                  "3", "abc", "1",                                              # view (bad id retried)
                  "5", "77",                                                    # done: unknown id -> error, menu continues
                  "0"]
        with mock.patch("builtins.input", side_effect=inputs):
            code, out, _ = self.run_cli("menu")
        self.assertEqual(code, 0)
        self.assertIn("This field is required.", out)
        self.assertIn("Invalid date", out)
        self.assertIn("Please enter a number from the menu.", out)
        self.assertIn("Error: No task found with ID 77.", out)
        _, out, _ = self.run_cli("list")
        self.assertIn("Menu task", out)

    def test_menu_exits_cleanly_on_eof(self):
        with mock.patch("builtins.input", side_effect=EOFError):
            code, _, _ = self.run_cli()
        self.assertEqual(code, 0)

    def test_render_table_marks_overdue(self):
        from datetime import date
        table = render_table([Task(1, "Old", due_date=date(2020, 1, 1))], today=date(2026, 1, 1))
        self.assertIn("2020-01-01 !", table)
        self.assertEqual(render_table([]), "No tasks found.")


if __name__ == "__main__":
    unittest.main()
