import math
import unittest

from exercises.ex1_classes import Book, Library
from exercises.ex2_inheritance import Developer, Manager
from exercises.ex3_polymorphism import Circle, Rectangle, Shape, Triangle, total_area
from exercises.ex4_encapsulation import BankAccount, InsufficientFundsError
from exercises.ex5_abstraction import EmailNotifier, Notifier, OrderService, SmsNotifier


class ExerciseTests(unittest.TestCase):
    def test_library(self):
        lib = Library("L")
        lib.add_book(Book("T", "Ann", "1"))
        self.assertEqual(len(lib.find_by_author("ann")), 1)
        lib.checkout("1")
        with self.assertRaises(ValueError):
            lib.checkout("1")
        lib.return_book("1")
        with self.assertRaises(LookupError):
            lib.checkout("nope")

    def test_inheritance(self):
        boss = Manager("B", 1000)
        boss.add_report(Developer("D", 500, "Python"))
        self.assertEqual(boss.annual_pay(), 12_000 + 10_000)
        self.assertIn("Python", boss.team[0].describe())

    def test_polymorphism(self):
        shapes = [Circle(1), Rectangle(2, 3), Triangle(3, 4, 5)]
        self.assertTrue(all(isinstance(s, Shape) for s in shapes))
        self.assertAlmostEqual(total_area(shapes), math.pi + 6 + 6)
        with self.assertRaises(TypeError):
            Shape()
        with self.assertRaises(ValueError):
            Triangle(1, 1, 5)

    def test_encapsulation(self):
        acct = BankAccount("Ann", 100)
        with self.assertRaises(AttributeError):
            acct.balance = 1_000_000
        with self.assertRaises(InsufficientFundsError):
            acct.withdraw(500)
        with self.assertRaises(ValueError):
            acct.deposit(-5)
        self.assertEqual(acct.deposit(50), 150)

    def test_abstraction_and_composition(self):
        with self.assertRaises(TypeError):
            Notifier()
        for notifier, prefix in ((EmailNotifier(), "EMAIL"), (SmsNotifier(), "SMS")):
            service = OrderService(notifier)
            self.assertTrue(service.place_order("a@b.c", "Pen").startswith(prefix))
            self.assertEqual(service.order_count, 1)
        with self.assertRaises(ValueError):
            OrderService(EmailNotifier()).place_order("a", " ")


if __name__ == "__main__":
    unittest.main()
