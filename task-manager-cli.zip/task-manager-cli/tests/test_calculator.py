import unittest

from calculator.app import evaluate, format_number
from calculator.calculator import Calculator, OperationRegistry
from calculator.errors import CalculatorError
from calculator.operations import Add, Operation
from calculator.parser import ExpressionParser


class EvaluateTests(unittest.TestCase):
    def test_basic_operations(self):
        cases = {"2 + 3": "5", "10 - 4.5": "5.5", "6 * 7": "42", "9 / 4": "2.25",
                 "7 % 3": "1", "2 ** 10": "1024", "-5 + 2": "-3", "5 - -3": "8", "3*4": "12"}
        for expression, expected in cases.items():
            self.assertEqual(evaluate(expression), expected, expression)

    def test_errors(self):
        for bad in ("5 / 0", "5 % 0", "abc", "1 +", "1 ^ 2", "", "(-8) ** 0.5", "-8 ** 0.5", "0 ** -1", "10 ** 1000"):
            with self.assertRaises(CalculatorError, msg=bad):
                evaluate(bad)

    def test_format_number(self):
        self.assertEqual(format_number(3.0), "3")
        self.assertEqual(format_number(0.1 + 0.2), "0.3")


class OpenClosedTests(unittest.TestCase):
    def test_new_operation_needs_no_changes_to_existing_code(self):
        class Max(Operation):
            symbol = "max"

            def apply(self, left, right):
                return max(left, right)

        registry = OperationRegistry([Add(), Max()])
        calc = Calculator(registry)
        parser = ExpressionParser(registry.symbols)
        left, symbol, right = parser.parse("4 max 9")
        self.assertEqual(calc.calculate(left, symbol, right), 9)

    def test_duplicate_and_unknown_symbols(self):
        registry = OperationRegistry([Add()])
        with self.assertRaises(CalculatorError):
            registry.register(Add())
        with self.assertRaises(CalculatorError):
            registry.get("?")


if __name__ == "__main__":
    unittest.main()
