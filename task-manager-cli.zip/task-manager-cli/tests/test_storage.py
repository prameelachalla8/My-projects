import json
import tempfile
import unittest
from pathlib import Path

from taskmanager.exceptions import StorageError
from taskmanager.models import Priority, Task
from taskmanager.storage import JsonTaskRepository


class JsonRepositoryTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = Path(self._tmp.name) / "nested" / "tasks.json"
        self.repo = JsonTaskRepository(self.path)

    def test_missing_file_gives_empty_list(self):
        self.assertEqual(self.repo.load_all(), [])

    def test_empty_file_gives_empty_list(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text("   ")
        self.assertEqual(self.repo.load_all(), [])

    def test_round_trip_creates_parent_folder(self):
        self.repo.save_all([Task(1, "A", priority=Priority.HIGH), Task(2, "B")])
        loaded = self.repo.load_all()
        self.assertEqual([t.title for t in loaded], ["A", "B"])
        self.assertEqual(loaded[0].priority, Priority.HIGH)
        self.assertFalse(self.path.with_name("tasks.json.tmp").exists())

    def test_corrupt_json_raises_storage_error(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text("{not json")
        with self.assertRaises(StorageError):
            self.repo.load_all()

    def test_wrong_structure_raises(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text(json.dumps([1, 2, 3]))
        with self.assertRaises(StorageError):
            self.repo.load_all()

    def test_invalid_entry_names_its_position(self):
        self.path.parent.mkdir(parents=True)
        self.path.write_text(json.dumps({"tasks": [{"id": 1, "title": "ok"}, {"id": 2, "title": ""}]}))
        with self.assertRaisesRegex(StorageError, "#2"):
            self.repo.load_all()

    def test_duplicate_ids_rejected(self):
        self.path.parent.mkdir(parents=True)
        entry = {"id": 1, "title": "x"}
        self.path.write_text(json.dumps({"tasks": [entry, entry]}))
        with self.assertRaisesRegex(StorageError, "Duplicate"):
            self.repo.load_all()


if __name__ == "__main__":
    unittest.main()
