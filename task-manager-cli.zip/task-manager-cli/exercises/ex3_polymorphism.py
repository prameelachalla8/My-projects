"""Exercise 3 - Polymorphism: different shapes, one interface."""

import math
from abc import ABC, abstractmethod


class Shape(ABC):
    @abstractmethod
    def area(self) -> float:
        """Area of the shape."""

    @abstractmethod
    def perimeter(self) -> float:
        """Perimeter of the shape."""

    def describe(self) -> str:
        return f"{type(self).__name__}: area={self.area():.2f}, perimeter={self.perimeter():.2f}"


class Circle(Shape):
    def __init__(self, radius: float) -> None:
        if radius <= 0:
            raise ValueError("Radius must be positive.")
        self.radius = radius

    def area(self) -> float:
        return math.pi * self.radius**2

    def perimeter(self) -> float:
        return 2 * math.pi * self.radius


class Rectangle(Shape):
    def __init__(self, width: float, height: float) -> None:
        if width <= 0 or height <= 0:
            raise ValueError("Width and height must be positive.")
        self.width, self.height = width, height

    def area(self) -> float:
        return self.width * self.height

    def perimeter(self) -> float:
        return 2 * (self.width + self.height)


class Triangle(Shape):
    def __init__(self, a: float, b: float, c: float) -> None:
        if min(a, b, c) <= 0 or a + b <= c or a + c <= b or b + c <= a:
            raise ValueError("These sides do not form a triangle.")
        self.a, self.b, self.c = a, b, c

    def perimeter(self) -> float:
        return self.a + self.b + self.c

    def area(self) -> float:  # Heron's formula
        s = self.perimeter() / 2
        return math.sqrt(s * (s - self.a) * (s - self.b) * (s - self.c))


def total_area(shapes) -> float:
    """Works for any Shape - the caller never checks the concrete type."""
    return sum(shape.area() for shape in shapes)


def main() -> None:
    shapes = [Circle(2), Rectangle(3, 4), Triangle(3, 4, 5)]
    for shape in shapes:
        print(shape.describe())
    print(f"Total area: {total_area(shapes):.2f}")


if __name__ == "__main__":
    main()
