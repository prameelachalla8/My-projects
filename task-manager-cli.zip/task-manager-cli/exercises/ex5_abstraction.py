"""Exercise 5 - Abstraction and composition: notifications for an order service."""

from abc import ABC, abstractmethod


class Notifier(ABC):
    """The abstraction the order service depends on."""

    @abstractmethod
    def send(self, recipient: str, message: str) -> str:
        """Deliver a message and return a description of what was sent."""


class EmailNotifier(Notifier):
    def send(self, recipient: str, message: str) -> str:
        return f"EMAIL to {recipient}: {message}"


class SmsNotifier(Notifier):
    def send(self, recipient: str, message: str) -> str:
        return f"SMS to {recipient}: {message[:60]}"


class OrderService:
    """Has-a Notifier (composition) instead of being one, so it works with any channel."""

    def __init__(self, notifier: Notifier) -> None:
        self._notifier = notifier
        self._orders = []

    def place_order(self, customer: str, item: str) -> str:
        if not item.strip():
            raise ValueError("Item cannot be empty.")
        self._orders.append((customer, item))
        return self._notifier.send(customer, f"Your order for {item} is confirmed.")

    @property
    def order_count(self) -> int:
        return len(self._orders)


def main() -> None:
    for notifier in (EmailNotifier(), SmsNotifier()):
        print(OrderService(notifier).place_order("asha@example.com", "Keyboard"))


if __name__ == "__main__":
    main()
