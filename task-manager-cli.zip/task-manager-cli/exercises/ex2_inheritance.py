"""Exercise 2 - Inheritance: employees, developers and managers."""


class Employee:
    """Base class holding what every employee has in common."""

    def __init__(self, name: str, monthly_salary: float) -> None:
        self.name = name
        self.monthly_salary = monthly_salary

    def annual_pay(self) -> float:
        return self.monthly_salary * 12

    def describe(self) -> str:
        return f"{self.name} (employee), annual pay {self.annual_pay():,.0f}"


class Developer(Employee):
    """A developer is an employee who also knows a programming language."""

    def __init__(self, name: str, monthly_salary: float, language: str) -> None:
        super().__init__(name, monthly_salary)
        self.language = language

    def describe(self) -> str:
        return f"{self.name} (developer, {self.language}), annual pay {self.annual_pay():,.0f}"


class Manager(Employee):
    """A manager leads a team and receives an annual bonus per direct report."""

    BONUS_PER_REPORT = 10_000

    def __init__(self, name: str, monthly_salary: float) -> None:
        super().__init__(name, monthly_salary)
        self.team = []

    def add_report(self, employee: Employee) -> None:
        self.team.append(employee)

    def annual_pay(self) -> float:
        return super().annual_pay() + self.BONUS_PER_REPORT * len(self.team)

    def describe(self) -> str:
        return f"{self.name} (manager of {len(self.team)}), annual pay {self.annual_pay():,.0f}"


def main() -> None:
    dev = Developer("Asha", 60_000, "Python")
    boss = Manager("Ravi", 90_000)
    boss.add_report(dev)
    for person in (dev, boss):
        print(person.describe())


if __name__ == "__main__":
    main()
