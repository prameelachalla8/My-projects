"""Exercise 4 - Encapsulation: a bank account that protects its balance."""


class InsufficientFundsError(Exception):
    """Raised when a withdrawal is larger than the balance."""


class BankAccount:
    def __init__(self, owner: str, opening_balance: float = 0.0) -> None:
        self.owner = owner
        if opening_balance < 0:
            raise ValueError("Opening balance cannot be negative.")
        self.__balance = float(opening_balance)  # name-mangled: hidden from outside

    @property
    def owner(self) -> str:
        return self._owner

    @owner.setter
    def owner(self, value: str) -> None:
        if not value or not value.strip():
            raise ValueError("Owner name cannot be empty.")
        self._owner = value.strip()

    @property
    def balance(self) -> float:
        """Read-only: the balance can only change through deposit/withdraw."""
        return self.__balance

    def deposit(self, amount: float) -> float:
        if amount <= 0:
            raise ValueError("Deposit must be positive.")
        self.__balance += amount
        return self.__balance

    def withdraw(self, amount: float) -> float:
        if amount <= 0:
            raise ValueError("Withdrawal must be positive.")
        if amount > self.__balance:
            raise InsufficientFundsError(
                f"Cannot withdraw {amount:.2f}; balance is {self.__balance:.2f}."
            )
        self.__balance -= amount
        return self.__balance


def main() -> None:
    account = BankAccount("Prameela", 500)
    account.deposit(250)
    account.withdraw(100)
    print(f"{account.owner}: {account.balance:.2f}")
    try:
        account.withdraw(10_000)
    except InsufficientFundsError as exc:
        print(f"Blocked: {exc}")


if __name__ == "__main__":
    main()
