"""Exercise 1 - Classes and objects: a tiny library system."""


class Book:
    """A book with a title, author, ISBN and an availability flag."""

    def __init__(self, title: str, author: str, isbn: str) -> None:
        self.title = title
        self.author = author
        self.isbn = isbn
        self.is_available = True

    def __str__(self) -> str:
        state = "available" if self.is_available else "checked out"
        return f'"{self.title}" by {self.author} ({state})'


class Library:
    """Holds books and lets people check them out and return them."""

    def __init__(self, name: str) -> None:
        self.name = name
        self._books = []

    def add_book(self, book: Book) -> None:
        self._books.append(book)

    def find_by_author(self, author: str) -> list:
        return [b for b in self._books if b.author.lower() == author.lower()]

    def checkout(self, isbn: str) -> Book:
        book = self._find(isbn)
        if not book.is_available:
            raise ValueError(f"'{book.title}' is already checked out.")
        book.is_available = False
        return book

    def return_book(self, isbn: str) -> Book:
        book = self._find(isbn)
        book.is_available = True
        return book

    def _find(self, isbn: str) -> Book:
        for book in self._books:
            if book.isbn == isbn:
                return book
        raise LookupError(f"No book with ISBN {isbn}.")

    def __len__(self) -> int:
        return len(self._books)


def main() -> None:
    library = Library("City Library")
    library.add_book(Book("Clean Code", "Robert C. Martin", "111"))
    library.add_book(Book("The Pragmatic Programmer", "Andrew Hunt", "222"))
    print(library.checkout("111"))
    print(f"{len(library)} books in {library.name}")


if __name__ == "__main__":
    main()
