# Branching Strategy

This project follows a simplified **Git Flow**.

```
main      o-----------------------------------------o  (v1.0.0)
           \                                       /
develop     o---o-------o-------o-------o---------o
                 \     / \     / \     /
feature/*         o---o   o---o   o---o
```

## Branches

| Branch | Purpose | Created from | Merged into |
|---|---|---|---|
| `main` | Always stable and releasable. Every release is tagged (`v1.0.0`). | - | - |
| `develop` | Integration branch where finished features meet. | `main` | `main` (at release) |
| `feature/<name>` | One new feature or module, e.g. `feature/storage`. | `develop` | `develop` |
| `docs/<name>` | Documentation-only changes. | `develop` | `develop` |
| `fix/<name>` | Bug fix for `develop`. | `develop` | `develop` |
| `hotfix/<name>` | Urgent fix for a released version. | `main` | `main` and `develop` |

## Rules

1. Never commit directly to `main` or `develop`. Work on a branch and open a pull request.
2. Keep each branch focused on a single purpose and short-lived.
3. All tests must pass (`python -m unittest discover`) before a branch is merged.
4. Merge with `--no-ff` so the branch and its commits stay visible in the history.
5. Tag releases on `main` using semantic versioning (`vMAJOR.MINOR.PATCH`).

## Commit messages

Commits use the [Conventional Commits](https://www.conventionalcommits.org/) style:
`type(scope): short summary in the imperative mood`.

| Type | Use for |
|---|---|
| `feat` | A new feature |
| `fix` | A bug fix |
| `test` | Adding or improving tests |
| `docs` | Documentation only |
| `refactor` | Code change that neither fixes a bug nor adds a feature |
| `chore` | Tooling, config, housekeeping |

Examples: `feat(storage): add atomic JSON repository`, `test(service): cover not-found handling`.

## Typical workflow

```bash
git checkout develop
git pull
git checkout -b feature/due-date-reminders

# ...edit code, add tests...
git add taskmanager/ tests/
git commit -m "feat(service): list tasks due within N days"

git push -u origin feature/due-date-reminders
# open a pull request into develop, get it reviewed, then merge

git checkout develop
git merge --no-ff feature/due-date-reminders
git branch -d feature/due-date-reminders
```

## Releasing

```bash
git checkout main
git merge --no-ff develop -m "Release v1.0.0"
git tag -a v1.0.0 -m "Version 1.0.0"
git push origin main --tags
```
