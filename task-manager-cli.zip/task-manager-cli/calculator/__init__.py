"""A small calculator designed around the SOLID principles."""
