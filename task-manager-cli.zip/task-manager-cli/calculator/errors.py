"""Errors raised by the calculator package."""


class CalculatorError(Exception):
    """Raised for bad expressions, unknown operators and invalid maths."""
