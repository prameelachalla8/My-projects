"""Command-line front end and composition root (where objects are wired together).

Run with:  python -m calculator.app
"""

from .calculator import Calculator, OperationRegistry
from .errors import CalculatorError
from .operations import Add, Divide, Modulo, Multiply, Power, Subtract
from .parser import ExpressionParser


def format_number(value: float) -> str:
    if value == int(value) and abs(value) < 1e15:
        return str(int(value))
    return f"{value:.10g}"


def build_calculator() -> "tuple[Calculator, ExpressionParser]":
    registry = OperationRegistry([Add(), Subtract(), Multiply(), Divide(), Modulo(), Power()])
    return Calculator(registry), ExpressionParser(registry.symbols)


def evaluate(expression: str) -> str:
    calculator, parser = build_calculator()
    left, symbol, right = parser.parse(expression)
    return format_number(calculator.calculate(left, symbol, right))


def main() -> None:
    print("Calculator - type an expression like 12 * 3, or 'q' to quit. Operators: + - * / % **")
    while True:
        try:
            text = input("calc> ").strip()
        except EOFError:
            break
        if text.lower() in ("q", "quit", "exit"):
            break
        if not text:
            continue
        try:
            print(evaluate(text))
        except CalculatorError as exc:
            print(f"Error: {exc}")


if __name__ == "__main__":
    main()
