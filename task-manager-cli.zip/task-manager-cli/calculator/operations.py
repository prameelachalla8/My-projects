"""Arithmetic operations.

Open/Closed: add a new operation by writing a new ``Operation`` subclass;
nothing else in the package has to change.
Liskov: every subclass can be used wherever an ``Operation`` is expected.
"""

from abc import ABC, abstractmethod

from .errors import CalculatorError


class Operation(ABC):
    """Contract every operation fulfils."""

    @property
    @abstractmethod
    def symbol(self) -> str:
        """Text the user types, e.g. '+'."""

    @abstractmethod
    def apply(self, left: float, right: float) -> float:
        """Compute ``left <symbol> right``."""


class Add(Operation):
    symbol = "+"

    def apply(self, left: float, right: float) -> float:
        return left + right


class Subtract(Operation):
    symbol = "-"

    def apply(self, left: float, right: float) -> float:
        return left - right


class Multiply(Operation):
    symbol = "*"

    def apply(self, left: float, right: float) -> float:
        return left * right


class Divide(Operation):
    symbol = "/"

    def apply(self, left: float, right: float) -> float:
        if right == 0:
            raise CalculatorError("Cannot divide by zero.")
        return left / right


class Modulo(Operation):
    symbol = "%"

    def apply(self, left: float, right: float) -> float:
        if right == 0:
            raise CalculatorError("Cannot take a remainder by zero.")
        return left % right


class Power(Operation):
    symbol = "**"

    def apply(self, left: float, right: float) -> float:
        try:
            result = left**right
        except (OverflowError, ZeroDivisionError):
            raise CalculatorError("That power is too large or undefined.") from None
        if isinstance(result, complex):
            raise CalculatorError("The result is not a real number.")
        return result
