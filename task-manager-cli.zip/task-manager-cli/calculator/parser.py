"""Turns text such as ``12 * 3.5`` into numbers and an operator symbol.

Single Responsibility: parsing only. It knows nothing about how to calculate.
"""

import re
from typing import Iterable, Tuple

from .errors import CalculatorError

_NUMBER = r"[-+]?\d+(?:\.\d+)?"


class ExpressionParser:
    def __init__(self, symbols: Iterable[str]) -> None:
        # Longest symbols first so '**' is matched before '*'.
        operators = "|".join(re.escape(s) for s in sorted(symbols, key=len, reverse=True))
        self._pattern = re.compile(rf"^\s*({_NUMBER})\s*({operators})\s*({_NUMBER})\s*$")

    def parse(self, expression: str) -> Tuple[float, str, float]:
        match = self._pattern.match(expression)
        if not match:
            raise CalculatorError(
                f"Could not understand '{expression.strip()}'. Use: <number> <operator> <number>, e.g. 12 * 3."
            )
        return float(match.group(1)), match.group(2), float(match.group(3))
