"""Registry and Calculator.

Single Responsibility: the registry stores operations; the calculator runs them.
Dependency Inversion: ``Calculator`` depends on the ``Operation`` abstraction and
on a registry it is given, never on concrete operation classes.
"""

from typing import Dict, Iterable, List

from .errors import CalculatorError
from .operations import Operation


class OperationRegistry:
    """Looks up operations by their symbol."""

    def __init__(self, operations: Iterable[Operation] = ()) -> None:
        self._operations: Dict[str, Operation] = {}
        for operation in operations:
            self.register(operation)

    def register(self, operation: Operation) -> None:
        if operation.symbol in self._operations:
            raise CalculatorError(f"Operator '{operation.symbol}' is already registered.")
        self._operations[operation.symbol] = operation

    def get(self, symbol: str) -> Operation:
        try:
            return self._operations[symbol]
        except KeyError:
            raise CalculatorError(f"Unknown operator '{symbol}'.") from None

    @property
    def symbols(self) -> List[str]:
        return list(self._operations)


class Calculator:
    """Performs a calculation using whichever operations the registry holds."""

    def __init__(self, registry: OperationRegistry) -> None:
        self._registry = registry

    def calculate(self, left: float, symbol: str, right: float) -> float:
        return self._registry.get(symbol).apply(left, right)
