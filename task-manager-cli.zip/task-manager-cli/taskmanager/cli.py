"""Command-line interface (presentation layer) for the Task Manager."""

from __future__ import annotations

import argparse
import os
import sys
from datetime import date
from pathlib import Path
from typing import Callable, List, Optional, Sequence, TypeVar

from .exceptions import TaskManagerError, ValidationError
from .models import Priority, Status, Task
from .service import SORT_OPTIONS, TaskManager
from .storage import JsonTaskRepository
from .validators import clean_description, clean_title, parse_due_date, parse_task_id

ENV_VAR = "TASKMANAGER_FILE"
T = TypeVar("T")


def default_storage_path() -> Path:
    """TASKMANAGER_FILE if set, otherwise ~/.taskmanager/tasks.json."""
    override = os.environ.get(ENV_VAR)
    return Path(override) if override else Path.home() / ".taskmanager" / "tasks.json"


# --------------------------------------------------------------------------
# Formatting
# --------------------------------------------------------------------------
def _shorten(text: str, limit: int) -> str:
    return text if len(text) <= limit else text[: limit - 3] + "..."


def render_table(tasks: Sequence[Task], today: Optional[date] = None) -> str:
    """Render tasks as a plain-ASCII table (safe for any terminal)."""
    if not tasks:
        return "No tasks found."
    today = today or date.today()
    headers = ("ID", "PRIORITY", "STATUS", "DUE", "TITLE")
    rows = []
    for t in tasks:
        due = t.due_date.isoformat() if t.due_date else "-"
        if t.is_overdue(today):
            due += " !"
        rows.append((str(t.id), str(t.priority), str(t.status), due, _shorten(t.title, 40)))
    widths = [max([len(h)] + [len(r[i]) for r in rows]) for i, h in enumerate(headers)]

    def line(cells: Sequence[str]) -> str:
        return "  ".join(c.ljust(w) for c, w in zip(cells, widths)).rstrip()

    return "\n".join([line(headers), line(["-" * w for w in widths])] + [line(r) for r in rows])


def render_details(task: Task, today: Optional[date] = None) -> str:
    due = task.due_date.isoformat() if task.due_date else "-"
    if task.is_overdue(today):
        due += " (OVERDUE)"
    return "\n".join(
        [
            f"Task #{task.id}",
            f"  Title:       {task.title}",
            f"  Description: {task.description or '-'}",
            f"  Priority:    {task.priority}",
            f"  Status:      {task.status}",
            f"  Due:         {due}",
            f"  Created:     {task.created_at.strftime('%Y-%m-%d %H:%M:%S')}",
        ]
    )


# --------------------------------------------------------------------------
# Command handlers (one per sub-command)
# --------------------------------------------------------------------------
def cmd_add(manager: TaskManager, args: argparse.Namespace) -> None:
    due = parse_due_date(args.due) if args.due else None
    task = manager.add_task(args.title, args.description, Priority.from_string(args.priority), due)
    print(f"Added task #{task.id}: {task.title}")


def cmd_list(manager: TaskManager, args: argparse.Namespace) -> None:
    tasks = manager.list_tasks(
        status=Status.from_string(args.status) if args.status else None,
        priority=Priority.from_string(args.priority) if args.priority else None,
        overdue_only=args.overdue,
        sort_by=args.sort,
    )
    print(render_table(tasks))
    if tasks:
        print(f"\n{len(tasks)} task(s). '!' marks overdue tasks.")


def cmd_show(manager: TaskManager, args: argparse.Namespace) -> None:
    print(render_details(manager.get_task(parse_task_id(args.task_id))))


def cmd_update(manager: TaskManager, args: argparse.Namespace) -> None:
    changes = {}
    if args.title is not None:
        changes["title"] = args.title
    if args.description is not None:
        changes["description"] = args.description
    if args.priority is not None:
        changes["priority"] = Priority.from_string(args.priority)
    if args.status is not None:
        changes["status"] = Status.from_string(args.status)
    if args.due is not None and args.clear_due:
        raise ValidationError("Use either --due or --clear-due, not both.")
    if args.due is not None:
        changes["due_date"] = parse_due_date(args.due)
    if args.clear_due:
        changes["due_date"] = None
    task = manager.update_task(parse_task_id(args.task_id), **changes)
    print(f"Updated task #{task.id}: {task.title}")


def cmd_done(manager: TaskManager, args: argparse.Namespace) -> None:
    task = manager.mark_done(parse_task_id(args.task_id))
    print(f"Marked task #{task.id} as done: {task.title}")


def cmd_delete(manager: TaskManager, args: argparse.Namespace) -> None:
    task = manager.get_task(parse_task_id(args.task_id))
    if not args.yes and not confirm(f"Delete task #{task.id} '{task.title}'?"):
        print("Cancelled.")
        return
    manager.delete_task(task.id)
    print(f"Deleted task #{task.id}.")


def confirm(question: str) -> bool:
    try:
        return input(f"{question} [y/N] ").strip().lower() in ("y", "yes")
    except EOFError:
        return False


COMMANDS = {
    "add": cmd_add,
    "list": cmd_list,
    "show": cmd_show,
    "update": cmd_update,
    "done": cmd_done,
    "delete": cmd_delete,
}


# --------------------------------------------------------------------------
# Interactive menu
# --------------------------------------------------------------------------
_CLEAR = object()  # sentinel: "remove the due date"


def ask(prompt: str, parse: Callable[[str], T], *, required: bool = True) -> Optional[T]:
    """Keep asking until the input is valid. Blank returns None if optional."""
    while True:
        raw = input(prompt).strip()
        if not raw:
            if not required:
                return None
            print("  This field is required.")
            continue
        try:
            return parse(raw)
        except ValidationError as exc:
            print(f"  {exc}")


def _menu_add(manager: TaskManager) -> None:
    title = ask("Title: ", clean_title)
    description = ask("Description (optional): ", clean_description, required=False) or ""
    priority = ask("Priority low/medium/high (Enter = medium): ", Priority.from_string, required=False)
    due = ask("Due date YYYY-MM-DD (optional): ", parse_due_date, required=False)
    task = manager.add_task(title, description, priority or Priority.MEDIUM, due)
    print(f"Added task #{task.id}.")


def _menu_list(manager: TaskManager) -> None:
    print(render_table(manager.list_tasks(sort_by="due")))


def _menu_show(manager: TaskManager) -> None:
    print(render_details(manager.get_task(ask("Task ID: ", parse_task_id))))


def _menu_update(manager: TaskManager) -> None:
    task = manager.get_task(ask("Task ID to update: ", parse_task_id))
    print(render_details(task))
    print("Press Enter to keep a value.")
    changes = {}
    title = ask("New title: ", clean_title, required=False)
    if title is not None:
        changes["title"] = title
    description = ask("New description: ", clean_description, required=False)
    if description is not None:
        changes["description"] = description
    priority = ask("New priority low/medium/high: ", Priority.from_string, required=False)
    if priority is not None:
        changes["priority"] = priority
    status = ask("New status pending/in-progress/done: ", Status.from_string, required=False)
    if status is not None:
        changes["status"] = status
    due = ask(
        "New due date YYYY-MM-DD ('none' to clear): ",
        lambda v: _CLEAR if v.lower() == "none" else parse_due_date(v),
        required=False,
    )
    if due is not None:
        changes["due_date"] = None if due is _CLEAR else due
    if not changes:
        print("Nothing changed.")
        return
    manager.update_task(task.id, **changes)
    print(f"Updated task #{task.id}.")


def _menu_done(manager: TaskManager) -> None:
    task = manager.mark_done(ask("Task ID: ", parse_task_id))
    print(f"Marked task #{task.id} as done.")


def _menu_delete(manager: TaskManager) -> None:
    task = manager.get_task(ask("Task ID to delete: ", parse_task_id))
    if confirm(f"Delete task #{task.id} '{task.title}'?"):
        manager.delete_task(task.id)
        print(f"Deleted task #{task.id}.")
    else:
        print("Cancelled.")


MENU = (
    ("1", "Add task", _menu_add),
    ("2", "List tasks", _menu_list),
    ("3", "View task details", _menu_show),
    ("4", "Update task", _menu_update),
    ("5", "Mark task as done", _menu_done),
    ("6", "Delete task", _menu_delete),
)


def run_menu(manager: TaskManager) -> int:
    actions = {key: action for key, _label, action in MENU}
    while True:
        print("\n=== Task Manager ===")
        for key, label, _action in MENU:
            print(f"{key}. {label}")
        print("0. Exit")
        try:
            choice = input("Choose an option: ").strip()
        except EOFError:
            print()
            return 0
        if choice == "0":
            print("Goodbye!")
            return 0
        action = actions.get(choice)
        if action is None:
            print("Please enter a number from the menu.")
            continue
        try:
            action(manager)
        except TaskManagerError as exc:  # keep the menu alive after a bad action
            print(f"Error: {exc}")
        except EOFError:
            print()
            return 0


# --------------------------------------------------------------------------
# Argument parsing and entry point
# --------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="taskmanager",
        description="Manage tasks from the command line. Run with no command for an interactive menu.",
    )
    parser.add_argument("--file", help=f"JSON data file (default: ~/.taskmanager/tasks.json or ${ENV_VAR})")
    sub = parser.add_subparsers(dest="command", metavar="command")

    add = sub.add_parser("add", help="add a new task")
    add.add_argument("title")
    add.add_argument("-d", "--description", default="")
    add.add_argument("-p", "--priority", default="medium", help="low, medium or high")
    add.add_argument("--due", help="due date, YYYY-MM-DD")

    ls = sub.add_parser("list", help="list tasks")
    ls.add_argument("--status", help="pending, in-progress or done")
    ls.add_argument("--priority", help="low, medium or high")
    ls.add_argument("--overdue", action="store_true", help="only overdue tasks")
    ls.add_argument("--sort", choices=SORT_OPTIONS, default="id")

    show = sub.add_parser("show", help="show one task in detail")
    show.add_argument("task_id")

    upd = sub.add_parser("update", help="change a task")
    upd.add_argument("task_id")
    upd.add_argument("--title")
    upd.add_argument("--description")
    upd.add_argument("--priority", help="low, medium or high")
    upd.add_argument("--status", help="pending, in-progress or done")
    upd.add_argument("--due", help="new due date, YYYY-MM-DD")
    upd.add_argument("--clear-due", action="store_true", help="remove the due date")

    done = sub.add_parser("done", help="mark a task as done")
    done.add_argument("task_id")

    rm = sub.add_parser("delete", help="delete a task")
    rm.add_argument("task_id")
    rm.add_argument("-y", "--yes", action="store_true", help="skip the confirmation prompt")

    sub.add_parser("menu", help="interactive menu (default)")
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    path = Path(args.file) if args.file else default_storage_path()
    try:
        manager = TaskManager(JsonTaskRepository(path))
        if args.command in (None, "menu"):
            return run_menu(manager)
        COMMANDS[args.command](manager, args)
        return 0
    except TaskManagerError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nCancelled.", file=sys.stderr)
        return 130
