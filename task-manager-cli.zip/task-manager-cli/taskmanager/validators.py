"""Input validation helpers shared by the model, service and CLI layers."""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Optional

from .exceptions import ValidationError

MAX_TITLE_LENGTH = 100
MAX_DESCRIPTION_LENGTH = 500
DATE_FORMAT = "%Y-%m-%d"
_DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def clean_title(value: object) -> str:
    """Return a trimmed, single-spaced title or raise ValidationError."""
    if not isinstance(value, str):
        raise ValidationError("Title must be text.")
    title = " ".join(value.split())
    if not title:
        raise ValidationError("Title cannot be empty.")
    if len(title) > MAX_TITLE_LENGTH:
        raise ValidationError(
            f"Title is too long ({len(title)} characters; maximum is {MAX_TITLE_LENGTH})."
        )
    return title


def clean_description(value: object) -> str:
    """Return a trimmed description (empty string if None)."""
    if value is None:
        return ""
    if not isinstance(value, str):
        raise ValidationError("Description must be text.")
    text = value.strip()
    if len(text) > MAX_DESCRIPTION_LENGTH:
        raise ValidationError(
            f"Description is too long ({len(text)} characters; maximum is {MAX_DESCRIPTION_LENGTH})."
        )
    return text


def parse_date(value: object) -> date:
    """Parse a strict YYYY-MM-DD string into a date."""
    if not isinstance(value, str) or not _DATE_PATTERN.match(value.strip()):
        raise ValidationError(
            f"Invalid date '{value}'. Use the format YYYY-MM-DD (for example 2026-12-31)."
        )
    try:
        return datetime.strptime(value.strip(), DATE_FORMAT).date()
    except ValueError:
        raise ValidationError(f"'{value}' is not a real calendar date.") from None


def parse_due_date(
    value: object, *, allow_past: bool = False, today: Optional[date] = None
) -> date:
    """Parse a due date and (by default) reject dates in the past."""
    due = parse_date(value)
    today = today or date.today()
    if not allow_past and due < today:
        raise ValidationError(f"Due date {due.isoformat()} is in the past.")
    return due


def parse_task_id(value: object) -> int:
    """Parse a positive integer task ID."""
    try:
        task_id = int(str(value).strip())
    except ValueError:
        raise ValidationError(f"Invalid task ID '{value}'. Enter a whole number.") from None
    if task_id < 1:
        raise ValidationError("Task IDs start at 1.")
    return task_id
