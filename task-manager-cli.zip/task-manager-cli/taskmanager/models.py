"""Domain model: the Priority and Status enums and the Task entity."""

from __future__ import annotations

from datetime import date, datetime
from enum import Enum
from typing import Any, Dict, Optional

from .exceptions import ValidationError
from .validators import clean_description, clean_title, parse_date


class Priority(Enum):
    """How urgent a task is. Higher value means more urgent."""

    LOW = 1
    MEDIUM = 2
    HIGH = 3

    @classmethod
    def from_string(cls, value: object) -> "Priority":
        try:
            return cls[str(value).strip().upper()]
        except KeyError:
            raise ValidationError(
                f"Invalid priority '{value}'. Choose from: low, medium, high."
            ) from None

    def __str__(self) -> str:
        return self.name.lower()


class Status(Enum):
    """Where a task is in its life cycle."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    DONE = "done"

    @classmethod
    def from_string(cls, value: object) -> "Status":
        key = str(value).strip().lower().replace("-", "_").replace(" ", "_")
        for member in cls:
            if member.value == key:
                return member
        raise ValidationError(
            f"Invalid status '{value}'. Choose from: pending, in-progress, done."
        )

    def __str__(self) -> str:
        return self.value.replace("_", "-")


class Task:
    """A single to-do item. Fields are validated whenever they are set."""

    def __init__(
        self,
        task_id: int,
        title: str,
        description: str = "",
        priority: Any = Priority.MEDIUM,
        due_date: Optional[date] = None,
        status: Any = Status.PENDING,
        created_at: Optional[datetime] = None,
    ) -> None:
        if not isinstance(task_id, int) or isinstance(task_id, bool) or task_id < 1:
            raise ValidationError("Task ID must be a positive whole number.")
        self._id = task_id
        self.title = title
        self.description = description
        self.priority = priority
        self.due_date = due_date
        self.status = status
        if created_at is not None and not isinstance(created_at, datetime):
            raise ValidationError("created_at must be a datetime.")
        self._created_at = created_at or datetime.now().replace(microsecond=0)

    # --- read-only fields -------------------------------------------------
    @property
    def id(self) -> int:
        return self._id

    @property
    def created_at(self) -> datetime:
        return self._created_at

    # --- validated, editable fields --------------------------------------
    @property
    def title(self) -> str:
        return self._title

    @title.setter
    def title(self, value: str) -> None:
        self._title = clean_title(value)

    @property
    def description(self) -> str:
        return self._description

    @description.setter
    def description(self, value: Optional[str]) -> None:
        self._description = clean_description(value)

    @property
    def priority(self) -> Priority:
        return self._priority

    @priority.setter
    def priority(self, value: Any) -> None:
        self._priority = value if isinstance(value, Priority) else Priority.from_string(value)

    @property
    def status(self) -> Status:
        return self._status

    @status.setter
    def status(self, value: Any) -> None:
        self._status = value if isinstance(value, Status) else Status.from_string(value)

    @property
    def due_date(self) -> Optional[date]:
        return self._due_date

    @due_date.setter
    def due_date(self, value: Optional[date]) -> None:
        if value is not None and (
            not isinstance(value, date) or isinstance(value, datetime)
        ):
            raise ValidationError("Due date must be a date or None.")
        self._due_date = value

    # --- behaviour --------------------------------------------------------
    def is_overdue(self, today: Optional[date] = None) -> bool:
        """A task is overdue when it has a past due date and is not done."""
        today = today or date.today()
        return (
            self._due_date is not None
            and self._status is not Status.DONE
            and self._due_date < today
        )

    # --- (de)serialisation -----------------------------------------------
    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self._id,
            "title": self._title,
            "description": self._description,
            "priority": str(self._priority),
            "due_date": self._due_date.isoformat() if self._due_date else None,
            "status": self._status.value,
            "created_at": self._created_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: Any) -> "Task":
        if not isinstance(data, dict):
            raise ValidationError("A task entry must be an object.")
        try:
            task_id, title = data["id"], data["title"]
        except KeyError as missing:
            raise ValidationError(f"Missing field {missing}.") from None

        due_raw = data.get("due_date")
        due_date = parse_date(due_raw) if due_raw is not None else None

        created_raw = data.get("created_at")
        created_at = None
        if created_raw is not None:
            try:
                created_at = datetime.fromisoformat(created_raw)
            except (TypeError, ValueError):
                raise ValidationError(f"Invalid created_at '{created_raw}'.") from None

        return cls(
            task_id,
            title,
            data.get("description", ""),
            data.get("priority", "medium"),
            due_date,
            data.get("status", "pending"),
            created_at,
        )

    def __repr__(self) -> str:
        return f"Task(id={self._id}, title={self._title!r}, status={self._status})"
