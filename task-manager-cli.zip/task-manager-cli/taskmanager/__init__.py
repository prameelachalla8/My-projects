"""Task Manager CLI - a small, layered command-line task manager."""

__version__ = "1.0.0"
