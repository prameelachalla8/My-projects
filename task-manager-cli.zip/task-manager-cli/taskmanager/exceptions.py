"""Custom exceptions so every layer can fail with a clear, catchable error."""


class TaskManagerError(Exception):
    """Base class for all expected, user-facing errors."""


class ValidationError(TaskManagerError):
    """Raised when user input or stored data is invalid."""


class TaskNotFoundError(TaskManagerError):
    """Raised when a task ID does not exist."""

    def __init__(self, task_id: int) -> None:
        super().__init__(f"No task found with ID {task_id}.")
        self.task_id = task_id


class StorageError(TaskManagerError):
    """Raised when the data file cannot be read or written."""
