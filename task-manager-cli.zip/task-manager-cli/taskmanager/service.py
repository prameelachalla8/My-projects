"""Business logic: create, read, update and delete tasks."""

from __future__ import annotations

from datetime import date
from typing import Any, Dict, List, Optional

from .exceptions import TaskNotFoundError, ValidationError
from .models import Priority, Status, Task
from .storage import TaskRepository

SORT_OPTIONS = ("id", "priority", "due")
UPDATABLE_FIELDS = ("title", "description", "priority", "due_date", "status")


class TaskManager:
    """Coordinates tasks and saves them through a repository after each change."""

    def __init__(self, repository: TaskRepository) -> None:
        self._repository = repository
        self._tasks: Dict[int, Task] = {t.id: t for t in repository.load_all()}

    # --- Create -----------------------------------------------------------
    def add_task(
        self,
        title: str,
        description: str = "",
        priority: Priority = Priority.MEDIUM,
        due_date: Optional[date] = None,
    ) -> Task:
        task = Task(self._next_id(), title, description, priority, due_date)
        self._tasks[task.id] = task
        self._save()
        return task

    # --- Read -------------------------------------------------------------
    def get_task(self, task_id: int) -> Task:
        try:
            return self._tasks[task_id]
        except KeyError:
            raise TaskNotFoundError(task_id) from None

    def list_tasks(
        self,
        *,
        status: Optional[Status] = None,
        priority: Optional[Priority] = None,
        overdue_only: bool = False,
        sort_by: str = "id",
        today: Optional[date] = None,
    ) -> List[Task]:
        if sort_by not in SORT_OPTIONS:
            raise ValidationError(f"Cannot sort by '{sort_by}'. Choose from: {', '.join(SORT_OPTIONS)}.")
        today = today or date.today()
        tasks = [
            t
            for t in self._tasks.values()
            if (status is None or t.status is status)
            and (priority is None or t.priority is priority)
            and (not overdue_only or t.is_overdue(today))
        ]
        keys = {
            "id": lambda t: t.id,
            "priority": lambda t: (-t.priority.value, t.id),
            "due": lambda t: (t.due_date is None, t.due_date or date.max, t.id),
        }
        return sorted(tasks, key=keys[sort_by])

    # --- Update -----------------------------------------------------------
    def update_task(self, task_id: int, **changes: Any) -> Task:
        """Update fields atomically: either every change applies or none does."""
        unknown = set(changes) - set(UPDATABLE_FIELDS)
        if unknown:
            raise ValidationError(f"Cannot update: {', '.join(sorted(unknown))}.")
        if not changes:
            raise ValidationError("Nothing to update. Provide at least one field to change.")
        candidate = Task.from_dict(self.get_task(task_id).to_dict())
        for field, value in changes.items():
            setattr(candidate, field, value)  # setters validate each value
        self._tasks[task_id] = candidate
        self._save()
        return candidate

    def mark_done(self, task_id: int) -> Task:
        return self.update_task(task_id, status=Status.DONE)

    # --- Delete -----------------------------------------------------------
    def delete_task(self, task_id: int) -> Task:
        task = self.get_task(task_id)
        del self._tasks[task_id]
        self._save()
        return task

    # --- helpers ----------------------------------------------------------
    def _next_id(self) -> int:
        return max(self._tasks, default=0) + 1

    def _save(self) -> None:
        self._repository.save_all(self._tasks.values())
