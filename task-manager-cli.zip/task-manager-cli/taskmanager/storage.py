"""Persistence layer: an abstract repository and a JSON-file implementation."""

from __future__ import annotations

import json
import os
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Iterable, List, Union

from .exceptions import StorageError, ValidationError
from .models import Task

SCHEMA_VERSION = 1


class TaskRepository(ABC):
    """Interface the service depends on, so storage can be swapped (e.g. SQLite)."""

    @abstractmethod
    def load_all(self) -> List[Task]:
        """Return every stored task."""

    @abstractmethod
    def save_all(self, tasks: Iterable[Task]) -> None:
        """Replace the stored tasks with ``tasks``."""


class JsonTaskRepository(TaskRepository):
    """Stores tasks in a human-readable JSON file."""

    def __init__(self, path: Union[str, Path]) -> None:
        self._path = Path(path)

    @property
    def path(self) -> Path:
        return self._path

    def load_all(self) -> List[Task]:
        if not self._path.exists():
            return []
        try:
            text = self._path.read_text(encoding="utf-8")
        except OSError as exc:
            raise StorageError(f"Cannot read '{self._path}': {exc.strerror or exc}.") from exc
        if not text.strip():
            return []
        try:
            payload = json.loads(text)
        except json.JSONDecodeError as exc:
            raise StorageError(
                f"'{self._path}' is not valid JSON ({exc.msg}, line {exc.lineno}). "
                "Fix the file or delete it to start fresh."
            ) from exc
        if not isinstance(payload, dict) or not isinstance(payload.get("tasks"), list):
            raise StorageError(f"'{self._path}' has an unexpected format.")

        tasks: List[Task] = []
        seen = set()
        for index, entry in enumerate(payload["tasks"], start=1):
            try:
                task = Task.from_dict(entry)
            except ValidationError as exc:
                raise StorageError(f"Task entry #{index} in '{self._path}' is invalid: {exc}") from exc
            if task.id in seen:
                raise StorageError(f"Duplicate task ID {task.id} in '{self._path}'.")
            seen.add(task.id)
            tasks.append(task)
        return tasks

    def save_all(self, tasks: Iterable[Task]) -> None:
        payload = {"version": SCHEMA_VERSION, "tasks": [t.to_dict() for t in tasks]}
        temp_path = self._path.with_name(self._path.name + ".tmp")
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            temp_path.write_text(
                json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
            )
            os.replace(temp_path, self._path)  # atomic: never leaves a half-written file
        except OSError as exc:
            raise StorageError(f"Cannot write '{self._path}': {exc.strerror or exc}.") from exc
