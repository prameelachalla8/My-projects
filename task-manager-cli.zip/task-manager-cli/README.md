# Task Manager CLI

A command-line task manager built in Python for the Week 1 mini project.
Create, read, update and delete tasks with **priorities** and **due dates**,
stored in a **JSON** file, with **input validation**, **error handling** and
an object-oriented, layered design. It uses only the Python standard library.

## Features

- Add, list, show, update, complete and delete tasks
- Priorities (`low`, `medium`, `high`) and statuses (`pending`, `in-progress`, `done`)
- Optional due dates (`YYYY-MM-DD`) with overdue detection
- Filter by status, priority or overdue; sort by id, priority or due date
- Two ways to use it: sub-commands, or an interactive menu
- Atomic JSON saves (a crash never leaves a half-written file)
- Clear error messages instead of stack traces

## Requirements

Python 3.8 or newer. No packages to install.

## Quick start

```bash
git clone https://github.com/<your-username>/task-manager-cli.git
cd task-manager-cli

python main.py add "Finish Week 1 project" -p high --due 2026-12-31
python main.py list
```

On Windows you can use `py main.py ...` if `python` is not recognised.
You can also run it as a module: `python -m taskmanager list`.

## Usage

```text
python main.py [--file PATH] <command> [options]
```

| Command | Example |
|---|---|
| `add` | `python main.py add "Buy books" -d "For semester 2" -p medium --due 2026-12-15` |
| `list` | `python main.py list --status pending --priority high --sort due` |
| `list --overdue` | `python main.py list --overdue` |
| `show` | `python main.py show 1` |
| `update` | `python main.py update 1 --title "New title" --status in-progress --due 2026-12-20` |
| `update` (clear date) | `python main.py update 1 --clear-due` |
| `done` | `python main.py done 1` |
| `delete` | `python main.py delete 1` (asks to confirm; add `-y` to skip) |
| `menu` | `python main.py` or `python main.py menu` |

Example output:

```text
ID  PRIORITY  STATUS       DUE           TITLE
--  --------  -----------  ------------  ----------------------
1   high      in-progress  2026-12-31    Finish Week 1 project
2   medium    pending      2026-11-01 !  Buy books

2 task(s). '!' marks overdue tasks.
```

Invalid input never crashes the program:

```text
$ python main.py add "Report" --due 31/12/2026
Error: Invalid date '31/12/2026'. Use the format YYYY-MM-DD (for example 2026-12-31).
```

Exit codes: `0` success, `1` an error was reported, `2` bad command-line usage.

### Where is my data?

Tasks are saved to `~/.taskmanager/tasks.json` (your user folder). Change it with
`--file PATH` or the `TASKMANAGER_FILE` environment variable. Data files are in
`.gitignore`, so your personal tasks are never committed.

## Design

The code is split into layers, and each layer only depends on the one below it:

```text
cli.py        presentation: argument parsing, menu, formatting
service.py    business logic: TaskManager (CRUD, filtering, sorting)
storage.py    persistence: TaskRepository (abstract) + JsonTaskRepository
models.py     domain: Task, Priority, Status
validators.py input rules shared by every layer
exceptions.py TaskManagerError and its subclasses
```

OOP ideas used:

- **Encapsulation:** `Task` keeps its fields private and validates every change through property setters; `id` and `created_at` are read-only.
- **Abstraction and polymorphism:** `TaskManager` depends on the abstract `TaskRepository`, so JSON could be swapped for SQLite without touching the logic.
- **Enums:** `Priority` and `Status` prevent invalid values.
- **Custom exceptions:** `ValidationError`, `TaskNotFoundError` and `StorageError` are caught once, at the CLI boundary.

Error handling highlights: strict date parsing, trimmed and length-limited text, atomic multi-field
updates (all changes apply or none do), friendly messages for missing or corrupt data files.

## Project structure

```text
task-manager-cli/
├── main.py
├── taskmanager/        # the application
├── tests/              # 55 unit and end-to-end tests
├── exercises/          # 5 OOP practice exercises
├── calculator/         # SOLID calculator exercise
├── docs/BRANCHING.md   # branching strategy and commit conventions
├── README.md
├── LICENSE
└── .gitignore
```

## Running the tests

```bash
python -m unittest discover -v
```

## Foundations exercises

**OOP exercises** (`exercises/`): run any with `python -m exercises.ex1_classes`.

| File | Concept |
|---|---|
| `ex1_classes.py` | Classes and objects (library system) |
| `ex2_inheritance.py` | Inheritance (employees, developers, managers) |
| `ex3_polymorphism.py` | Polymorphism (shapes sharing one interface) |
| `ex4_encapsulation.py` | Encapsulation (bank account protecting its balance) |
| `ex5_abstraction.py` | Abstraction and composition (notification channels) |

**Calculator** (`calculator/`): run with `python -m calculator.app`. Type expressions such as `12 * 3` or `2 ** 10`.

| Principle | Where |
|---|---|
| **S**ingle Responsibility | Parsing (`parser.py`), operations (`operations.py`), lookup (`OperationRegistry`) and running (`Calculator`) are separate classes |
| **O**pen/Closed | Add a new operator by writing one `Operation` subclass and registering it; no existing code changes (see `test_calculator.py`) |
| **L**iskov Substitution | Every `Operation` subclass works wherever an `Operation` is expected |
| **I**nterface Segregation | `Operation` has a minimal contract: `symbol` and `apply` |
| **D**ependency Inversion | `Calculator` depends on the `Operation` abstraction and an injected registry, wired together in `app.py` |

## Git workflow

The repository uses a Git Flow style: `main` (stable, tagged), `develop` (integration) and
short-lived `feature/*` branches merged with `--no-ff`. Commits follow Conventional Commits.
See [docs/BRANCHING.md](docs/BRANCHING.md).

## License

Released under the [MIT License](LICENSE).
